TODO

--Verify accuracy

--See how it works on 8-Ks

--????
